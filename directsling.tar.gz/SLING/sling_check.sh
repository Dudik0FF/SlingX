#!/bin/bash


if pidof -o %PPID -x "sling_check.sh">/dev/null; then
    echo "Process already running"
        exit 1
fi

mkdir -p log

sed '/^$/d' channel_id.txt | while read line; do
i=$(cut -d";" -f1 <<< $line)
  if [[ ! -f "/home/mini_cs/hls/${i}/hls/playlist.m3u8" ||  `find  /home/mini_cs/hls/${i}/hls/playlist.m3u8 -mmin +1 2> /dev/null`  ||  `find  /home/SLING/${i}/file.txt  -mmin +1 2> /dev/null` ]] ; then
       rm -rf /home/mini_cs/hls/${i}
       rm -rf /home/SLING/${i}
       kill `ps ax | grep -v grep | grep "/home/SLING/SLING.php ${i}" | awk '{print $1}'` && echo "kill by bash" >> log/${i}.txt  2>&1
  fi
if ps ax | grep -v grep | grep "/home/SLING/SLING.php ${i}" > /dev/null
 then
   echo "An another instance of this script is already running ${i}"
      if [[ ! -f /home/SLING/${i}/PID ]]; then
        kill `ps ax | grep -v grep | grep "/home/SLING/SLING.php ${i}" | awk '{print $1}'` && echo "kill by bash" >> log/${i}.txt  2>&1
      fi
   else
  if [[ ! -e /home/SLING/${i}/PID || ! -d /home/mini_cs/hls/${i} ]]; then
      echo "starting ${i}"
     /home/mini_cs/php/bin/php /home/SLING/SLING.php ${i} >> log/${i}.txt 2>&1 &
  fi
fi
done

