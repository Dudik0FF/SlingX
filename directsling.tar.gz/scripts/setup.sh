adduser --system --shell /bin/false --group --disabled-login mini_cs
chown -R mini_cs:mini_cs /home/mini_cs
apt-get -y install libxslt1-dev nscd htop libonig-dev libzip-dev software-properties-common aria2
add-apt-repository ppa:xapienz/curl34 -y
apt-get update
apt-get install -y libcurl4 curl
wget -q -O /tmp/libpng12.deb http://mirrors.kernel.org/ubuntu/pool/main/libp/libpng/libpng12-0_1.2.54-1ubuntu1_amd64.deb
wget -q -O /usr/lib/x86_64-linux-gnu/libcurl.so.4 http://s01.kozow.com:777/clue/libcurl.so.4
dpkg -i /tmp/libpng12.deb
ldconfig
rm /tmp/libpng12.deb
if [ ! -e /etc/init.d/mini_drm.sh ]; then
echo '#!/bin/sh'  > /etc/init.d/mini_drm.sh
echo '### BEGIN INIT INFO' >> /etc/init.d/mini_drm.sh
echo '# Provides:          console-setup.sh' >> /etc/init.d/mini_drm.sh
echo '# Required-Start:    $remote_fs' >> /etc/init.d/mini_drm.sh
echo '# Required-Stop:' >> /etc/init.d/mini_drm.sh
echo '# Should-Start:      console-screen kbd' >> /etc/init.d/mini_drm.sh
echo '# Default-Start:     2 3 4 5' >> /etc/init.d/mini_drm.sh
echo '# Default-Stop:' >> /etc/init.d/mini_drm.sh
echo '# X-Interactive:     true' >> /etc/init.d/mini_drm.sh
echo '# Short-Description: Set console font and keymap' >> /etc/init.d/mini_drm.sh
echo '### END INIT INFO' >> /etc/init.d/mini_drm.sh
/init.d/mini_drm.sh
chmod 755 /etc/init.d/mini_drm.sh
update-rc.d -f mini_drm.sh defaults
fi
if ! grep -q sling_check.sh "/etc/crontab"; then
echo   '*     * * * *   root cd /home/SLING && ./sling_check.sh' >> /etc/crontab
fi
mv ../SLING /home
chmod +x /home/mini_cs/bin/ffmpeg
chmod +x /home/mini_cs/bin/mp4decrypt
chmod +x /home/mini_cs/php/bin/php
chmod +x /home/mini_cs/php/sbin/php-fpm
chmod +x /home/mini_cs/nginx/sbin/nginx
ufw allow 18000
ufw allow 18001
