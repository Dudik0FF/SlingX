<?php
$rConfig = Array(
    "video_port" => 18000,
    "segments_sling" => 10,
    "segments_dstv" => 10,
    "segments_bell" => 10,
);
